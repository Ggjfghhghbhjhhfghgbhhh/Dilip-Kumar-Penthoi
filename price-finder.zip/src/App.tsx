import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Settings, 
  Upload, 
  SlidersHorizontal, 
  History, 
  Check, 
  Plus, 
  FileText, 
  Printer, 
  Zap, 
  ShieldAlert, 
  X, 
  Volume2, 
  Mic, 
  ArrowRightLeft, 
  Smartphone, 
  RefreshCw, 
  Edit3, 
  Trash2, 
  ExternalLink, 
  Percent, 
  Calendar, 
  Download,
  AlertCircle,
  Clock,
  Eye,
  Layers,
  Sparkles,
  ChevronRight,
  Database
} from 'lucide-react';
import { Product, CableCalculationInput, CableCalculationResult, PDFUploadHistory } from './types';

export default function App() {
  // DB & State
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([]);
  const [compareList, setCompareList] = useState<Product[]>([]);
  const [activeTab, setActiveTab] = useState<'search' | 'categories' | 'calculator' | 'admin'>('search');
  
  // Filter States
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedBrand, setSelectedBrand] = useState<string>('');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedMaterial, setSelectedMaterial] = useState<string>('');
  const [popularOnly, setPopularOnly] = useState<boolean>(false);

  // Admin View states
  const [adminTab, setAdminTab] = useState<'upload' | 'catalog' | 'analytics'>('upload');
  const [pdfHistory, setPdfHistory] = useState<PDFUploadHistory[]>([]);
  const [uploadBrand, setUploadBrand] = useState('PRAYAG');
  const [uploadCategory, setUploadCategory] = useState('PTMT Fittings');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadFileName, setUploadFileName] = useState('');
  const [uploadBase64, setUploadBase64] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [simulatedFileText, setSimulatedFileText] = useState('Select a pricing PDF or write a prompt to simulate extraction');
  const [ocrResults, setOcrResults] = useState<Product[]>([]);
  
  // Custom Product Add / Edit forms
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProductForm, setNewProductForm] = useState<Partial<Product>>({
    name: '', brand: '', category: 'LED Lighting', subcategory: 'General',
    size: '', material: '', minPrice: 0, medPrice: 0, watt: ''
  });
  const [showAddForm, setShowAddForm] = useState(false);

  // Search Queries Analytics
  const [topSearches, setTopSearches] = useState<{ term: string; count: number }[]>([]);

  // Voice recognition helper
  const [isListening, setIsListening] = useState(false);

  // Cable Calculator State
  const [calcInput, setCalcInput] = useState<CableCalculationInput>({
    loadType: 'KW',
    loadValue: 15,
    voltage: 'Three Phase (415V)',
    cableLength: 100,
    installationType: 'Direct in Ground',
    conductorType: 'Aluminium',
    cableType: 'XLPE Armoured'
  });
  const [calcResult, setCalcResult] = useState<CableCalculationResult | null>(null);

  // Detail Modal popup
  const [viewingDetailProduct, setViewingDetailProduct] = useState<Product | null>(null);

  // Theme support
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // References
  const searchRef = useRef<HTMLDivElement>(null);

  // Initial Boot load
  useEffect(() => {
    fetchProducts();
    fetchHistoryAndAnalytics();
    
    // Load local search history & recently viewed
    const localHist = localStorage.getItem('pricefinder_search_history');
    if (localHist) setSearchHistory(JSON.parse(localHist));

    // Listen outside suggestion click
    const handleOutsideClick = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Sync suggestion fetching
  useEffect(() => {
    if (searchTerm.trim().length > 1) {
      const delayDebounce = setTimeout(async () => {
        try {
          const res = await fetch(`/api/suggest?q=${encodeURIComponent(searchTerm)}`);
          if (res.ok) {
            const data = await res.json();
            setSuggestions(data);
          }
        } catch (err) {}
      }, 200);
      return () => clearTimeout(delayDebounce);
    } else {
      setSuggestions([]);
    }
  }, [searchTerm]);

  // Recalculate cable anytime calculation variables modify
  useEffect(() => {
    calculateCableDetails();
  }, [calcInput]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      let url = `/api/products?popular=${popularOnly}`;
      if (selectedCategory) url += `&category=${encodeURIComponent(selectedCategory)}`;
      if (selectedBrand) url += `&brand=${encodeURIComponent(selectedBrand)}`;
      if (selectedSize) url += `&size=${encodeURIComponent(selectedSize)}`;
      if (selectedMaterial) url += `&material=${encodeURIComponent(selectedMaterial)}`;
      
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchHistoryAndAnalytics = async () => {
    try {
      const histRes = await fetch('/api/pdf-history');
      if (histRes.ok) {
        const histData = await histRes.json();
        setPdfHistory(histData);
      }

      const analyticRes = await fetch('/api/analytics');
      if (analyticRes.ok) {
        const analyticData = await analyticRes.json();
        setTopSearches(analyticData.queries?.slice(0, 10) || []);
      }
    } catch (err) {}
  };

  const triggerSearch = async (term: string) => {
    setSearchTerm(term);
    setShowSuggestions(false);
    setLoading(true);
    try {
      // Log search analysis stats in database
      await fetch('/api/analytics/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ term })
      });

      // Update history list in React state
      const nextHist = [term, ...searchHistory.filter(h => h !== term)].slice(0, 8);
      setSearchHistory(nextHist);
      localStorage.setItem('pricefinder_search_history', JSON.stringify(nextHist));

      // Fetch products filtered by the term
      const url = `/api/products?q=${encodeURIComponent(term)}` + 
        (selectedCategory ? `&category=${encodeURIComponent(selectedCategory)}` : '') +
        (selectedBrand ? `&brand=${encodeURIComponent(selectedBrand)}` : '');
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
      
      fetchHistoryAndAnalytics(); // reload analytics counting
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyQuickFilter = (categoryName: string) => {
    setSelectedCategory(categoryName);
    setActiveTab('search');
    // Scroll smoothly to list anchor
    document.getElementById('catalog-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const clearAllFilters = () => {
    setSelectedCategory('');
    setSelectedBrand('');
    setSelectedSize('');
    setSelectedMaterial('');
    setSearchTerm('');
    setPriceRange([0, 10000]);
    setPopularOnly(false);
    fetchProducts();
  };

  // Run on filter trigger
  useEffect(() => {
    fetchProducts();
  }, [selectedCategory, selectedBrand, selectedSize, selectedMaterial, popularOnly]);

  // Voice Speech Recognition Controller
  const startVoiceRecognition = () => {
    const SpeechRecognition = 
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Voice search is not supported in this browser version. Please type in search query instead.");
      return;
    }

    const rec = new SpeechRecognition();
    rec.lang = 'en-IN'; // Optimized for Indian accented English
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    rec.onstart = () => {
      setIsListening(true);
    };

    rec.onresult = (event: any) => {
      const speechToText = event.results[0][0].transcript;
      triggerSearch(speechToText);
    };

    rec.onerror = (e: any) => {
      console.error(e);
      setIsListening(false);
    };

    rec.onend = () => {
      setIsListening(false);
    };

    rec.start();
  };

  // Compare Handler
  const toggleCompare = (product: Product) => {
    const exists = compareList.find(p => p.id === product.id);
    if (exists) {
      setCompareList(compareList.filter(p => p.id !== product.id));
    } else {
      if (compareList.length >= 3) {
        alert("You can compare up to 3 products at a time.");
        return;
      }
      setCompareList([...compareList, product]);
    }
  };

  // Add Product Flow
  const handleCreateProduct = async () => {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProductForm)
      });
      if (res.ok) {
        alert("Product added successfully into searchable database.");
        setShowAddForm(false);
        setNewProductForm({
          name: '', brand: '', category: 'LED Lighting', subcategory: 'General',
          size: '', material: '', minPrice: 0, medPrice: 0, watt: ''
        });
        fetchProducts();
      }
    } catch (err) {}
  };

  // Edit Product Flow
  const handleUpdateProduct = async () => {
    if (!editingProduct) return;
    try {
      const res = await fetch(`/api/products/${editingProduct.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingProduct)
      });
      if (res.ok) {
        alert("Product pricing updated successfully.");
        setEditingProduct(null);
        fetchProducts();
      }
    } catch (err) {}
  };

  // Delete Product Flow
  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Are you sure you want to permanently delete this hardware item? This change is irreversible.")) return;
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        alert("Product deleted.");
        fetchProducts();
      }
    } catch (err) {}
  };

  // View Product Details
  const handleViewProduct = (p: Product) => {
    setViewingDetailProduct(p);
    
    // Add to recently viewed
    setRecentlyViewed(prev => {
      const filtered = prev.filter(item => item.id !== p.id);
      return [p, ...filtered].slice(0, 6);
    });
  };

  // PDF Parser drag and drop or upload handling
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadFile(file);
      setUploadFileName(file.name);
      
      const reader = new FileReader();
      reader.onload = () => {
        const base64Str = (reader.result as string).split(',')[1];
        setUploadBase64(base64Str);
      };
      reader.readAsDataURL(file);

      // Simulate parsing text visual helper
      setSimulatedFileText(`Selected file: ${file.name} (${Math.round(file.size / 1024)} KB)\nAI Model: gemini-3.5-flash will execute table OCR extraction for Indian market rates.`);
    }
  };

  // Process PDF either via simulated smart model or real server Gemini OCR model trigger.
  const handleProcessPdf = async () => {
    if (!uploadBase64) {
      // Let's create a simulated base64 payload to ensure standard usage compiles and works even without real files
      const simulatedDummyBase64 = "JVBERi0xLjQKJSDi48b3Cg=="; // base PDF header
      setUploadBase64(simulatedDummyBase64);
    }

    setIsUploading(true);
    try {
      const payload = {
        base64: uploadBase64 || "JVBERi0xLjQKJSDi48b3Cg==",
        fileName: uploadFileName || `Simulated_${uploadBrand}_List.pdf`,
        brand: uploadBrand,
        category: uploadCategory
      };

      const res = await fetch('/api/admin/parse-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const output = await res.json();
        setOcrResults(output.extractedProducts || []);
        alert(`Successfully compiled PDF! Extracted ${output.extractedCount} items automatically. Review parsed values below before saving.`);
        fetchHistoryAndAnalytics();
        fetchProducts();
      } else {
        const errObj = await res.json();
        alert("Validation error during parser execution: " + errObj.error);
      }
    } catch (error: any) {
      alert("Error parsing document list: " + error.message);
    } finally {
      setIsUploading(false);
    }
  };

  // Accept OCR parsed suggestions and save to search catalog
  const handleApproveOcrProducts = () => {
    setOcrResults([]);
    alert("Extracted company catalog approved and loaded into searchable database.");
    fetchProducts();
    setActiveTab('search');
  };

  // Custom Cable Calculator Algorithm
  const calculateCableDetails = () => {
    const { loadType, loadValue, voltage, conductorType, cableType, cableLength } = calcInput;
    let amps = 0;

    // 1. Calculate Current in Amperes
    const powerFactor = 0.85; // Standard industrial assumed value
    if (loadType === 'Amps') {
      amps = Number(loadValue);
    } else if (loadType === 'KW') {
      if (voltage.includes('Three Phase')) {
        // Amps = kW * 1000 / (1.732 * 415 * pf)
        amps = (Number(loadValue) * 1000) / (1.732 * 415 * powerFactor);
      } else {
        // Amps = kW * 1000 / (230 * pf)
        amps = (Number(loadValue) * 1000) / (230 * powerFactor);
      }
    } else if (loadType === 'HP') {
      const kW = Number(loadValue) * 0.746;
      if (voltage.includes('Three Phase')) {
        amps = (kW * 1000) / (1.732 * 415 * powerFactor);
      } else {
        amps = (kW * 1000) / (230 * powerFactor);
      }
    }

    // 2. Recommend Cable size based on current carrying ampacity standards (Indian polycab XLPE chart)
    let recommendedSize = "1.5 sq mm";
    let ampacity = 15;
    let pricePerMeterMin = 15;
    let pricePerMeterMed = 19;

    const sizeMapping = [
      { size: "2.5 sq mm", maxAmpsAl: 18, maxAmpsCu: 24, minP: 22, medP: 27 },
      { size: "4 sq mm", maxAmpsAl: 25, maxAmpsCu: 32, minP: 35, medP: 42 },
      { size: "6 sq mm", maxAmpsAl: 32, maxAmpsCu: 41, minP: 50, medP: 61 },
      { size: "10 sq mm", maxAmpsAl: 44, maxAmpsCu: 57, minP: 75, medP: 90 },
      { size: "16 sq mm", maxAmpsAl: 60, maxAmpsCu: 78, minP: 110, medP: 130 },
      { size: "25 sq mm", maxAmpsAl: 85, maxAmpsCu: 110, minP: 155, medP: 185 },
      { size: "35 sq mm", maxAmpsAl: 105, maxAmpsCu: 135, minP: 185, medP: 215 },
      { size: "50 sq mm", maxAmpsAl: 130, maxAmpsCu: 165, minP: 240, medP: 280 },
      { size: "70 sq mm", maxAmpsAl: 165, maxAmpsCu: 210, minP: 340, medP: 395 },
      { size: "95 sq mm", maxAmpsAl: 202, maxAmpsCu: 260, minP: 450, medP: 520 },
      { size: "120 sq mm", maxAmpsAl: 230, maxAmpsCu: 300, minP: 580, medP: 670 }
    ];

    const isAl = conductorType === 'Aluminium';
    let matched = sizeMapping[0];
    
    for (const mapping of sizeMapping) {
      const capacity = isAl ? mapping.maxAmpsAl : mapping.maxAmpsCu;
      if (amps <= capacity) {
        matched = mapping;
        break;
      }
      matched = mapping; // fallback to largest if exceeded
    }

    recommendedSize = matched.size;
    ampacity = isAl ? matched.maxAmpsAl : matched.maxAmpsCu;
    pricePerMeterMin = matched.minP + (isAl ? 0 : 45); // copper has solid price premium
    pricePerMeterMed = matched.medP + (isAl ? 0 : 55);

    // 3. Estimate voltage drop
    // Formula approximation: V_drop = (1.73 * I * L * (R*cosPhi + X*sinPhi)) / 1000 [3-phase]
    // Resistance factor approximation: Aluminium has higher resistance than Copper
    const resistanceMultiplier = isAl ? 1.6 : 1.0;
    const sizeInNum = parseFloat(recommendedSize);
    const baseResistance = (0.0175 / sizeInNum) * resistanceMultiplier; // rough physical resistance
    const lengthInKm = Number(cableLength) / 1000;
    
    let voltDifference = 0;
    const multiphaseFactor = voltage.includes('Three Phase') ? 1.732 : 2.0;
    voltDifference = multiphaseFactor * amps * baseResistance * lengthInKm;
    
    const sourceVolt = voltage.includes('Three Phase') ? 415 : 230;
    const vDropPercent = (voltDifference / sourceVolt) * 100;
    const voltLimitExceeded = vDropPercent > 5.0; // Indian Regulatory Code limit

    setCalcResult({
      recommendedSize,
      ampacity,
      voltageDrop: Number(voltDifference.toFixed(2)),
      voltageDropPercent: Number(vDropPercent.toFixed(2)),
      voltageDropLimitExceeded: voltLimitExceeded,
      minPricePerMeter: Math.round(pricePerMeterMin),
      medPricePerMeter: Math.round(pricePerMeterMed),
      brandName: conductorType === 'Aluminium' ? "Polycab XLPE" : "KEI FR Pure Copper"
    });
  };

  // Dynamic CSV Download or Beautiful Quotation Printer
  const triggerExportReceipt = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const listHtml = products.map((p, index) => `
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="padding: 10px; font-weight: 600;">${index + 1}</td>
        <td style="padding: 10px;">
          <div style="font-weight: 600; font-family: 'Space Grotesk', sans-serif;">${p.name}</div>
          <span style="font-size: 11px; background: #e2e8f0; padding: 2px 6px; border-radius: 4px; color:#475569;">${p.brand}</span>
        </td>
        <td style="padding: 10px; color: #475569; font-size: 13px;">${p.category}</td>
        <td style="padding: 10px; font-weight: 500; font-size: 13px;">${p.size || 'Standard'}</td>
        <td style="padding: 10px; font-weight: 700; color: #d97706;">₹${p.minPrice}</td>
        <td style="padding: 10px; font-weight: 700; color: #1e3a8a;">₹${p.medPrice}</td>
        <td style="padding: 10px; font-size: 12px; color: #16a34a; font-weight:600;">Available (Stock Checked)</td>
      </tr>
    `).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>Price Finder - Quotation Estimation</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 30px; color: #1e293b; }
            .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #1e3a8a; padding-bottom: 15px; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th { background: #f1f5f9; padding: 12px; font-weight: 700; text-align: left; font-size: 13px; color: #1e3a8a; text-transform: uppercase; }
            .footer { margin-top: 50px; text-align: center; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 15px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1 style="margin: 0; color: #1e3a8a; font-family: 'Space Grotesk', sans-serif; font-size: 26px;">PRICE FINDER</h1>
              <p style="margin: 2px 0 0 0; font-size: 12px; color: #475569;">Indian Hardware & Electrical Market Value Directory</p>
            </div>
            <div style="text-align: right;">
              <p style="margin: 0; font-weight: 700;">Date: ${new Date().toLocaleDateString('en-IN')}</p>
              <p style="margin: 2px 0 0 0; font-size: 11px; color: #64748b;">Report Version: v1.8 (LTS)</p>
            </div>
          </div>
          <h3 style="color:#d97706; margin-bottom:10px;">Market Rate Analysis Report</h3>
          <p style="font-size:12px; margin:0 0 20px 0; max-width:600px; color:#475569;">
            This estimate lists minimum and medium range Indian wholesale/retail market prices of commercial, electrical, plumbing and plywood materials. It serves contractors, retailers, and electricians in pricing reference assessments.
          </p>
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Product Description</th>
                <th>Category</th>
                <th>Spec / Size</th>
                <th>Min (Wholesale/Builder)</th>
                <th>Med (Standard Budget Retail)</th>
                <th>Availability</th>
              </tr>
            </thead>
            <tbody>
              ${listHtml}
            </tbody>
          </table>
          <div class="footer">
            <p>Generated instantly on Price Finder Dashboard for gulubasini18@gmail.com.</p>
            <p>Disclaimer: Actual prices may vary locally + or - 5% based on freight, copper indices, and state tax differences.</p>
          </div>
          <script>window.print();</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc]/90 text-slate-900'} transition-colors duration-200`}>
      
      {/* Header Bar */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-brand-blue-900 text-white shadow-md border-b border-brand-blue-100/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => clearAllFilters()}>
            <div className="bg-brand-orange-500 text-white p-2 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Search className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight font-display flex items-center">
                Price Finder
                <span className="ml-1.5 text-[9px] font-semibold bg-brand-orange-500 text-white px-1.5 py-0.5 rounded uppercase">
                  India Live
                </span>
              </h1>
              <p className="text-[10px] text-slate-300">Indian Market Tradesman Directory</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex space-x-1">
            <button 
              onClick={() => { setActiveTab('search'); }}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'search' ? 'bg-white/10 text-brand-orange-500 border-b-2 border-brand-orange-500' : 'text-slate-200 hover:bg-white/5'}`}
            >
              Search Hub
            </button>
            <button 
              onClick={() => { setActiveTab('categories'); }}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'categories' ? 'bg-white/10 text-brand-orange-500 border-b-2 border-brand-orange-500' : 'text-slate-200 hover:bg-white/5'}`}
            >
              Category Cards
            </button>
            <button 
              onClick={() => { setActiveTab('calculator'); }}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center space-x-1 transition-colors ${activeTab === 'calculator' ? 'bg-white/10 text-brand-orange-500 border-b-2 border-brand-orange-500' : 'text-slate-200 hover:bg-white/5'}`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Cable Calculator</span>
            </button>
            <button 
              onClick={() => { setActiveTab('admin'); }}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium flex items-center space-x-1.5 transition-colors ${activeTab === 'admin' ? 'bg-white/10 text-brand-orange-500 border-b-2 border-brand-orange-500' : 'text-slate-200 hover:bg-white/5'}`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Admin PDF Portal</span>
            </button>
          </nav>

          {/* Utility buttons */}
          <div className="flex items-center space-x-3">
            <label className="relative inline-flex items-center cursor-pointer select-none">
              <input 
                type="checkbox" 
                checked={darkMode}
                onChange={() => setDarkMode(!darkMode)}
                className="sr-only peer" 
              />
              <div className="w-9 h-5 bg-slate-700 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-brand-orange-500"></div>
              <span className="ml-1 text-xs font-semibold text-slate-300 hidden sm:inline">Night Mode</span>
            </label>

            <button 
              onClick={() => triggerExportReceipt()}
              className="bg-brand-orange-500 hover:bg-brand-orange-600 transition-colors text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Download Price PDF</span>
            </button>

            {/* Mobile Nav Menu Indicator */}
            <div className="md:hidden flex space-x-1">
              <button 
                onClick={() => setActiveTab('admin')} 
                className="p-1 rounded bg-slate-800 text-white hover:bg-slate-700"
                title="Admin Mode"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setActiveTab('calculator')} 
                className="p-1 rounded bg-slate-800 text-white hover:bg-slate-700" 
                title="Calculator"
              >
                <Zap className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Search Section & Quick Analytics (Only visible if searching tabs) */}
      {activeTab === 'search' && (
        <section className={`relative pt-12 pb-10 px-4 sm:px-6 lg:px-8 border-b transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-brand-blue-900 text-white border-brand-blue-100/10'}`}>
          <div className="max-w-4xl mx-auto text-center">
            
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-brand-orange-500 text-white mb-4 shadow">
              <Sparkles className="w-3 h-3 mr-1" />
              AI-Powered Indian Hardware & Electrical Price Index
            </span>

            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-3 font-display">
              Instantly Search Spot Rates &amp; Builder Prices
            </h2>
            <p className={`text-sm max-w-2xl mx-auto mb-8 ${darkMode ? 'text-slate-300' : 'text-slate-100'}`}>
              Compare budget and medium-range price lists extracted from official company trade lists: PRAYAG, POLYCAB, CROWN, JAYNAM, SHAKTI &amp; BVI. Clean. Live. Transparent.
            </p>

            {/* Main Interactive Search Input Component */}
            <div ref={searchRef} className="relative max-w-2xl mx-auto mb-5">
              <div className="relative flex items-center">
                <div className="absolute left-4 text-slate-400">
                  <Search className="w-5 h-5 pointer-events-none" />
                </div>
                <input
                  type="text"
                  placeholder="e.g., '9W LED bulb', 'PRAYAG PTMT bib cock', 'Polycab 4 sq mm cable'..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setShowSuggestions(true);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      triggerSearch(searchTerm);
                    }
                  }}
                  className={`w-full py-4.5 pl-12 pr-28 rounded-2xl text-base font-medium shadow-xl focus:outline-none focus:ring-2 focus:ring-brand-orange-500 transition-all ${darkMode ? 'bg-slate-800 text-white border-slate-700' : 'bg-white text-slate-900 border-slate-200'}`}
                />
                
                <div className="absolute right-2 flex items-center space-x-2">
                  <button
                    onClick={() => startVoiceRecognition()}
                    className={`p-2.5 rounded-xl ${isListening ? 'bg-red-500 text-white animate-bounce' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'} transition-all`}
                    title="Voice Search"
                  >
                    <Mic className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => triggerSearch(searchTerm)}
                    className="bg-brand-orange-500 hover:bg-brand-orange-600 font-bold text-xs text-white px-4 py-2.5 rounded-xl transition-all"
                  >
                    Search
                  </button>
                </div>
              </div>

              {/* Auto Suggestions dropdown */}
              {showSuggestions && suggestions.length > 0 && (
                <div className={`absolute z-30 left-0 right-0 mt-2 rounded-xl shadow-2xl border text-left overflow-hidden max-h-75 overflow-y-auto ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'}`}>
                  {suggestions.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => triggerSearch(s)}
                      className={`w-full text-left px-4 py-3 text-sm flex items-center space-x-2 transition-colors ${darkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-100'}`}
                    >
                      <Search className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-medium">{s}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Voice listening status indicator */}
            {isListening && (
              <div className="max-w-2xl mx-auto bg-brand-orange-500 text-white text-xs font-semibold py-1.5 px-3 rounded-lg mb-4 animate-pulse flex items-center justify-center space-x-2">
                <Volume2 className="w-3.5 h-3.5" />
                <span>Microphone status: Active. Speak clearly into your mic (e.g. "9W Philips bulb")...</span>
              </div>
            )}

            {/* Popular and Recent Search Stats history pills */}
            <div className="flex flex-wrap items-center justify-center space-x-2 max-w-2xl mx-auto">
              <span className={`text-xs font-semibold uppercase flex items-center ${darkMode ? 'text-slate-400' : 'text-slate-200'}`}>
                <History className="w-3.5 h-3.5 mr-1" /> History:
              </span>
              {searchHistory.length === 0 ? (
                <span className={`text-xs italic ${darkMode ? 'text-slate-500' : 'text-slate-300'}`}>No prior searches</span>
              ) : (
                searchHistory.map((h, i) => (
                  <div key={i} className="inline-flex items-center bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-full text-xs font-medium text-white transition-colors cursor-pointer mb-2 space-x-1">
                    <span onClick={() => triggerSearch(h)}>{h}</span>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        const next = searchHistory.filter(item => item !== h);
                        setSearchHistory(next);
                        localStorage.setItem('pricefinder_search_history', JSON.stringify(next));
                      }}
                      className="hover:text-red-400 text-[10px]"
                    >
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Search Analytics Tag pills for standard user flow */}
            <div className="mt-4 flex flex-wrap items-center justify-center space-x-2 max-w-2xl mx-auto border-t border-white/10 pt-4">
              <span className={`text-[10px] font-bold tracking-wider uppercase ${darkMode ? 'text-slate-400' : 'text-slate-300'}`}>
                ⚡ Top Electrician & Contractor Searches:
              </span>
              {topSearches.slice(0, 5).map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => triggerSearch(q.term)}
                  className={`text-slate-100 hover:text-white hover:bg-brand-orange-500/20 text-xs py-1 px-2.5 rounded-lg border border-white/20 hover:border-brand-orange-500 transition-all font-mono`}
                >
                  {q.term} ({q.count})
                </button>
              ))}
            </div>

          </div>
        </section>
      )}

      {/* Category Grid Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Quick Tabs switcher */}
        <div className="md:hidden flex space-x-2 border-b border-slate-200 pb-3 mb-6 overflow-x-auto">
          <button 
            onClick={() => setActiveTab('search')} 
            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${activeTab === 'search' ? 'bg-brand-blue-900 text-white' : 'bg-slate-100'}`}
          >
            Search Hub
          </button>
          <button 
            onClick={() => setActiveTab('categories')} 
            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${activeTab === 'categories' ? 'bg-brand-blue-900 text-white' : 'bg-slate-100'}`}
          >
            Category Cards
          </button>
          <button 
            onClick={() => setActiveTab('calculator')} 
            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${activeTab === 'calculator' ? 'bg-brand-blue-900 text-white' : 'bg-slate-100'}`}
          >
            Cable Calculator
          </button>
          <button 
            onClick={() => setActiveTab('admin')} 
            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap ${activeTab === 'admin' ? 'bg-brand-blue-900 text-white' : 'bg-slate-100'}`}
          >
            Admin Panel
          </button>
        </div>

        {/* Recently Viewed Block (If present) */}
        {recentlyViewed.length > 0 && activeTab === 'search' && (
          <div className="mb-8 border-b border-slate-200 pb-6">
            <h3 className="text-sm font-bold uppercase text-slate-500 flex items-center mb-3">
              <Clock className="w-4 h-4 mr-1 text-brand-orange-500" /> Recently Viewed
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              {recentlyViewed.map(item => (
                <div
                  key={item.id}
                  onClick={() => handleViewProduct(item)}
                  className={`p-3 rounded-xl border flex items-center space-x-2.5 cursor-pointer hover:shadow transition-all ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}
                >
                  <img src={item.imageUrl} className="w-10 h-10 object-cover rounded-md" alt="" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate text-slate-800 dark:text-slate-100">{item.name}</p>
                    <p className="text-[10px] text-slate-500 font-mono">₹{item.minPrice} - ₹{item.medPrice}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main tabs rendering */}
        {activeTab === 'categories' && (
          <div>
            <h2 className="text-2xl font-bold tracking-tight mb-2 font-display">Explore Premium Category Modules</h2>
            <p className="text-slate-500 text-xs mb-6">Select a category to inspect budget-to-medium Indian hardware pricing indexes.</p>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              
              {/* Category Cards with dynamic counts on hover */}
              {[
                { name: 'PTMT Fittings', icon: '🚰', desc: 'Prayag, Shakti plastic taps/bib cocks' },
                { name: 'CP Fittings', icon: '🚿', desc: 'Brass electroplated pillar showers' },
                { name: 'Door Fittings', icon: '🔑', desc: 'Crown heavy handles, blocks, storers' },
                { name: 'Valves', icon: '⚙️', desc: 'BVI gate and butterfly industrial valves' },
                { name: 'Sanitary Items', icon: '🚽', desc: 'Flushing cisterns and bathroom ABS bodies' },
                { name: 'Kitchen Fittings', icon: '🍳', desc: 'Premium stainless steel sinks' },
                { name: 'Plywood', icon: '🌲', desc: 'National/Century 18mm & waterproof sheets' },
                { name: 'LED Lighting', icon: '💡', desc: '9W, 12W, 18W Havells, Anchor, Philips bulbs' },
                { name: 'Street Lights', icon: '🛣️', desc: 'IP65/IP66 high-wattage path illumination' },
                { name: 'Garden Lights', icon: '🏡', desc: 'Outdoor spike pathway pillar elements' },
                { name: 'Exhaust Fans', icon: '🌀', desc: 'High RPM ventilation fan units' },
                { name: 'Electrical Cables', icon: '⚡', desc: 'XLPE armoured Aluminium Poly & Kei wires' },
                { name: 'Copper Wires', icon: '🔴', desc: 'Single-core flexible FR/FRLS coils' },
                { name: 'Switches & Sockets', icon: '🔌', desc: 'Modular 6A-16A switch plates, bell buzzers' },
                { name: 'Electrical Protection', icon: '🛡️', desc: 'Legrand SP/DP MCBs and distribution boxes' },
                { name: 'Road Safety', icon: '🚧', desc: 'SHAKTI and Dak Eye premium cones, solar road studs & safety mirrors' }
              ].map((c, i) => (
                <div 
                  key={i}
                  onClick={() => handleApplyQuickFilter(c.name)}
                  className={`p-5 rounded-2xl border text-left cursor-pointer hover:shadow-xl hover:border-brand-orange-500 transition-all ${selectedCategory === c.name ? 'border-brand-orange-500 ring-2 ring-brand-orange-500/20' : ''} ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}
                >
                  <div className="w-10 h-10 rounded-xl bg-brand-orange-500/10 flex items-center justify-center text-xl mb-3">
                    {c.icon}
                  </div>
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100 font-display">{c.name}</h4>
                  <p className="text-[11px] text-slate-500 mt-1">{c.desc}</p>
                  <div className="mt-3 flex items-center text-xs font-semibold text-brand-orange-500">
                    <span>Inspect List</span>
                    <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'calculator' && (
          <div className={`p-6 rounded-3xl border shadow-xl ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex flex-col md:flex-row md:items-center justify-between border-b pb-4 mb-6">
              <div>
                <h2 className="text-xl font-bold font-display flex items-center text-brand-orange-500">
                  <Zap className="w-5 h-5 mr-1.5 animate-bounce" />
                  Professional XLPE &amp; PVC Cable Sizing Calculator
                </h2>
                <p className="text-xs text-slate-500">Computes regulatory current-capacity &amp; voltage drop metrics targeting KEI &amp; Polycab.</p>
              </div>
              <span className="bg-slate-100 text-slate-700 text-[10px] uppercase font-bold py-1 px-2.5 rounded-lg mt-2 md:mt-0">
                Indian Standard: IS 7098
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Inputs */}
              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Load Type</label>
                  <select 
                    value={calcInput.loadType}
                    onChange={(e) => setCalcInput({...calcInput, loadType: e.target.value as any})}
                    className={`w-full p-2.5 rounded-lg border text-sm font-semibold text-slate-800 ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                  >
                    <option value="KW">Kilowatts (kW)</option>
                    <option value="HP">Horsepower (HP)</option>
                    <option value="Amps">Amperes (Amps)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Load Metric Value</label>
                  <input 
                    type="number"
                    value={calcInput.loadValue}
                    onChange={(e) => setCalcInput({...calcInput, loadValue: Number(e.target.value)})}
                    className={`w-full p-2 rounded-lg border text-sm font-semibold ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Grid Voltage Grade</label>
                  <select 
                    value={calcInput.voltage}
                    onChange={(e) => setCalcInput({...calcInput, voltage: e.target.value as any})}
                    className={`w-full p-2.5 rounded-lg border text-sm font-semibold text-slate-800 ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                  >
                    <option>Single Phase (230V)</option>
                    <option>Three Phase (415V)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Route Length (Meters)</label>
                  <input 
                    type="number"
                    value={calcInput.cableLength}
                    onChange={(e) => setCalcInput({...calcInput, cableLength: Number(e.target.value)})}
                    className={`w-full p-2 rounded-lg border text-xs font-semibold ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Conductor Material type</label>
                  <div className="flex space-x-2">
                    {['Aluminium', 'Copper'].map(mat => (
                      <button
                        key={mat}
                        onClick={() => setCalcInput({...calcInput, conductorType: mat as any})}
                        className={`flex-1 py-2 text-xs font-bold rounded-lg border transition-all ${calcInput.conductorType === mat ? 'bg-brand-orange-500 text-white border-brand-orange-500' : 'bg-slate-50 border-slate-200 text-slate-700 dark:bg-slate-800'}`}
                      >
                        {mat}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Cable Shield Insulations</label>
                  <select 
                    value={calcInput.cableType}
                    onChange={(e) => setCalcInput({...calcInput, cableType: e.target.value as any})}
                    className={`w-full p-2.5 rounded-lg border text-xs font-semibold text-slate-800 ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                  >
                    <option>XLPE Armoured</option>
                    <option>PVC Flexible</option>
                  </select>
                </div>
              </div>

              {/* Sizing Recommendations Box */}
              <div className="bg-slate-50 dark:bg-slate-800 p-5 rounded-2xl border border-slate-150 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">
                    Calculator recommendation
                  </span>
                  {calcResult && (
                    <>
                      <h3 className="text-3xl font-extrabold text-brand-orange-500 tracking-tight mb-2">
                        {calcResult.recommendedSize}
                      </h3>
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 mb-4">
                        Conductor: {calcInput.conductorType} {calcInput.cableType}
                      </p>

                      <div className="space-y-2 border-t border-slate-200 pt-3">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Amperes Flowing:</span>
                          <span className="font-mono font-bold text-slate-700 dark:text-slate-100">
                            {calcInput.loadValue} {calcInput.loadType}
                          </span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Current Capacity:</span>
                          <span className="font-bold text-green-600">Max {calcResult.ampacity}A</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Total Voltage Drop:</span>
                          <span className={`font-bold ${calcResult.voltageDropLimitExceeded ? 'text-red-500' : 'text-slate-700 dark:text-slate-100'}`}>
                            {calcResult.voltageDrop}V ({calcResult.voltageDropPercent}%)
                          </span>
                        </div>
                      </div>

                      {calcResult.voltageDropLimitExceeded && (
                        <div className="mt-3 bg-red-100/80 p-2.5 rounded-xl text-[11px] text-red-700 font-medium flex items-start space-x-1 border border-red-200">
                          <ShieldAlert className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                          <span>Voltage drop exceeds Indian Regulatory safety recommendation limit (5.0%). Upgrade thickness to reduce line resistance.</span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                <div className="border-t border-slate-200 pt-4 mt-4">
                  <div className="flex justify-between text-xs font-bold mb-2">
                    <span className="text-slate-500">Estimates Market Rate (Per Meter):</span>
                  </div>
                  {calcResult && (
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold uppercase">Min Spot Rate</span>
                        <span className="text-lg font-bold text-brand-orange-500">₹{calcResult.minPricePerMeter}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold uppercase">Medium Spot Rate</span>
                        <span className="text-lg font-bold text-brand-blue-900 dark:text-white">₹{calcResult.medPricePerMeter}</span>
                      </div>
                    </div>
                  )}
                  <button 
                    onClick={() => triggerSearch(`${calcInput.conductorType} cable ${calcResult?.recommendedSize}`)}
                    className="w-full mt-4 bg-brand-blue-900 text-white text-xs font-bold py-2 rounded-lg hover:bg-brand-blue-800 transition-colors"
                  >
                    Search Cable in Database
                  </button>
                </div>

              </div>
            </div>
          </div>
        )}

        {/* Admin Dashboard view */}
        {activeTab === 'admin' && (
          <div className={`p-6 rounded-3xl border shadow-xl ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            
            {/* Dashboard Header tab switches */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-4 mb-6">
              <div>
                <h2 className="text-xl font-bold font-display flex items-center">
                  <Settings className="w-5 h-5 mr-1.5 text-brand-orange-500" />
                  India Tradesman Database Portal
                </h2>
                <p className="text-xs text-slate-500">OCR parsing, PDF version history, custom listings control.</p>
              </div>
              <div className="flex space-x-1.5 mt-3 sm:mt-0 bg-slate-100 p-1 rounded-xl">
                <button 
                  onClick={() => setAdminTab('upload')} 
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${adminTab === 'upload' ? 'bg-white text-slate-950 shadow' : 'text-slate-500'}`}
                >
                  OCR Parser
                </button>
                <button 
                  onClick={() => setAdminTab('catalog')} 
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${adminTab === 'catalog' ? 'bg-white text-slate-950 shadow' : 'text-slate-500'}`}
                >
                  Deduplicate Table
                </button>
                <button 
                  onClick={() => setAdminTab('analytics')} 
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${adminTab === 'analytics' ? 'bg-white text-slate-950 shadow' : 'text-slate-500'}`}
                >
                  Popular Searches
                </button>
              </div>
            </div>

            {adminTab === 'upload' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Upload configuration parameters */}
                <div className="space-y-4">
                  <div className="bg-brand-orange-500/5 p-4 rounded-xl border border-brand-orange-500/20">
                    <p className="text-xs text-brand-orange-500 font-bold mb-2 flex items-center">
                      <Sparkles className="w-4 h-4 mr-1 text-brand-orange-500 animate-spin" />
                      Gemini OCR document engine
                    </p>
                    <p className="text-[11px] text-slate-600 line-clamp-3">
                      Select or drop any PDF wholesale booklet file. The system routes scanned tables to the Gemini model to reconstruct pricing categories.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Company / Brand</label>
                    <select 
                      value={uploadBrand} 
                      onChange={(e) => setUploadBrand(e.target.value)}
                      className={`w-full p-2 rounded-lg border text-xs font-semibold ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                    >
                      <option>PRAYAG</option>
                      <option>SHAKTI</option>
                      <option>Dak Eye</option>
                      <option>JAYNAM</option>
                      <option>PRIMA</option>
                      <option>Black Pearl</option>
                      <option>BVI</option>
                      <option>Crown</option>
                      <option>National Plywood</option>
                      <option>Century Plywood</option>
                      <option>Polycab</option>
                      <option>KEI</option>
                      <option>Havells</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Product Category</label>
                    <select 
                      value={uploadCategory} 
                      onChange={(e) => setUploadCategory(e.target.value)}
                      className={`w-full p-2 rounded-lg border text-xs font-semibold ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200'}`}
                    >
                      <option>PTMT Fittings</option>
                      <option>CP Fittings</option>
                      <option>Door Fittings</option>
                      <option>Valves</option>
                      <option>Sanitary Items</option>
                      <option>Kitchen Fittings</option>
                      <option>Plywood</option>
                      <option>LED Lighting</option>
                      <option>Street Lights</option>
                      <option>Garden Lights</option>
                      <option>Exhaust Fans</option>
                      <option>Electrical Cables</option>
                      <option>Copper Wires</option>
                      <option>Switches & Sockets</option>
                      <option>Electrical Protection</option>
                      <option>Road Safety</option>
                    </select>
                  </div>

                  {/* Drag and Drop Zone file upload */}
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Company PDF Attachment</label>
                    <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-brand-orange-500 rounded-2xl p-6 text-center cursor-pointer transition-all relative">
                      <input 
                        type="file" 
                        accept=".pdf"
                        onChange={handleFileSelect}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-200">Drag &amp; Drop pricing sheet</p>
                      <p className="text-[10px] text-slate-400 mt-1">Accepts trade list text or scanned booklets (.pdf)</p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleProcessPdf()}
                    disabled={isUploading}
                    className="w-full bg-brand-orange-500 hover:bg-brand-orange-600 disabled:bg-slate-400 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center space-x-1.5 transition-colors shadow-lg shadow-orange-500/20"
                  >
                    {isUploading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Extracting with Gemini AI...</span>
                      </>
                    ) : (
                      <>
                        <Database className="w-4 h-4" />
                        <span>Run OCR &amp; Price Alignment</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Simulated file output review block */}
                <div className="lg:col-span-2 space-y-4">
                  <div className={`p-4 rounded-xl border font-mono text-[10px] whitespace-pre-wrap max-h-56 overflow-y-auto ${darkMode ? 'bg-slate-950 border-slate-800 text-green-400' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
                    <span className="text-slate-400 font-bold block mb-1">Document Stream Logs:</span>
                    {simulatedFileText}
                  </div>

                  {/* History of changes with status values */}
                  <div className="border rounded-2xl overflow-hidden">
                    <div className="bg-slate-50 dark:bg-slate-800 p-3 border-b text-xs font-bold text-slate-700 dark:text-slate-200">
                      PDF Update Version History Logs
                    </div>
                    <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
                      {pdfHistory.map(h => (
                        <div key={h.id} className="p-3 text-xs flex items-center justify-between">
                          <div>
                            <div className="font-semibold text-slate-800 dark:text-slate-100">{h.fileName}</div>
                            <div className="text-[10px] text-slate-400">
                              Uploaded: {new Date(h.uploadDate).toLocaleString('en-IN')} | Version {h.version}
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="bg-green-150 text-green-700 py-0.5 px-2 rounded font-bold text-[9px] uppercase border border-green-200 mr-2">
                              {h.status}
                            </span>
                            <span className="font-mono text-[11px] text-slate-500">
                              +{h.extractedCount} Items
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* OCR Parsed Grid Results Preview */}
                {ocrResults.length > 0 && (
                  <div className="lg:col-span-3 border border-brand-orange-500/20 rounded-2xl overflow-hidden mt-4">
                    <div className="bg-brand-orange-500/10 p-3.5 border-b border-brand-orange-500/25 flex items-center justify-between">
                      <span className="text-xs font-bold text-brand-orange-500">
                        AI OCR Extracted Listings Alignment Preview
                      </span>
                      <button 
                        onClick={() => handleApproveOcrProducts()}
                        className="bg-brand-orange-500 text-xs font-bold text-white py-1 px-3.5 rounded-lg hover:bg-brand-orange-600"
                      >
                        Approve &amp; Inject to Online Directory
                      </button>
                    </div>
                    <div className="divide-y divide-slate-150 max-h-80 overflow-y-auto">
                      {ocrResults.map((item, idx) => (
                        <div key={idx} className="p-3.5 text-xs grid grid-cols-1 sm:grid-cols-4 gap-2 items-center">
                          <div className="font-bold text-slate-800 dark:text-slate-100">{item.name}</div>
                          <div className="text-slate-500">Category: {uploadCategory} | Brand: {uploadBrand}</div>
                          <div className="font-mono text-xs">Spec Size: {item.size || '15mm'}</div>
                          <div className="font-bold text-slate-700 dark:text-slate-300 flex space-x-3 justify-end">
                            <span className="text-orange-500">Min: ₹{item.minPrice}</span>
                            <span className="text-indigo-600">Med: ₹{item.medPrice}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            )}

            {adminTab === 'catalog' && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200">
                    Live Indexed Products Database Table
                  </h3>
                  <button 
                    onClick={() => { setShowAddForm(true); setEditingProduct(null); }}
                    className="bg-brand-orange-500 text-white text-xs font-bold py-1.5 px-3 rounded-lg flex items-center space-x-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Post New Product</span>
                  </button>
                </div>

                {/* Add/Edit custom product inline overlay */}
                {(showAddForm || editingProduct) && (
                  <div className="p-5 rounded-2xl border border-brand-orange-500/25 bg-brand-orange-500/5 mb-6">
                    <div className="flex items-center justify-between border-b pb-2 mb-4">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                        {editingProduct ? 'Modify Product Specifications' : 'Post Brand New Catalog Item'}
                      </span>
                      <button 
                        onClick={() => { setShowAddForm(false); setEditingProduct(null); }}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Product Label</label>
                        <input 
                          type="text"
                          value={editingProduct ? editingProduct.name : newProductForm.name}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, name: e.target.value})
                            : setNewProductForm({...newProductForm, name: e.target.value})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Brand Company</label>
                        <input 
                          type="text"
                          value={editingProduct ? editingProduct.brand : newProductForm.brand}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, brand: e.target.value})
                            : setNewProductForm({...newProductForm, brand: e.target.value})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Specification / Size</label>
                        <input 
                          type="text"
                          value={editingProduct ? editingProduct.size : newProductForm.size}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, size: e.target.value})
                            : setNewProductForm({...newProductForm, size: e.target.value})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Min Price (₹)</label>
                        <input 
                          type="number"
                          value={editingProduct ? editingProduct.minPrice : newProductForm.minPrice}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, minPrice: Number(e.target.value)})
                            : setNewProductForm({...newProductForm, minPrice: Number(e.target.value)})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Med Price (₹)</label>
                        <input 
                          type="number"
                          value={editingProduct ? editingProduct.medPrice : newProductForm.medPrice}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, medPrice: Number(e.target.value)})
                            : setNewProductForm({...newProductForm, medPrice: Number(e.target.value)})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Material Category</label>
                        <input 
                          type="text"
                          value={editingProduct ? editingProduct.material : newProductForm.material}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, material: e.target.value})
                            : setNewProductForm({...newProductForm, material: e.target.value})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Watt Rating (if LED)</label>
                        <input 
                          type="text"
                          value={editingProduct ? editingProduct.watt : newProductForm.watt}
                          onChange={(e) => editingProduct 
                            ? setEditingProduct({...editingProduct, watt: e.target.value})
                            : setNewProductForm({...newProductForm, watt: e.target.value})
                          }
                          className="w-full p-2 text-xs border rounded-lg"
                        />
                      </div>
                    </div>

                    <div className="mt-4 flex justify-end space-x-2">
                      <button 
                        onClick={() => { setShowAddForm(false); setEditingProduct(null); }}
                        className="bg-slate-200 text-slate-700 text-xs font-bold py-1.5 px-4 rounded-lg"
                      >
                        Cancel
                      </button>
                      <button 
                        onClick={() => editingProduct ? handleUpdateProduct() : handleCreateProduct()}
                        className="bg-brand-orange-500 text-white text-xs font-bold py-1.5 px-4 rounded-lg"
                      >
                        Submit Changes
                      </button>
                    </div>
                  </div>
                )}

                {/* Database Table layout */}
                <div className="overflow-x-auto border rounded-xl">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 dark:bg-slate-800 text-[10px] font-extrabold uppercase text-slate-500 border-b">
                        <th className="p-3">Product Name</th>
                        <th className="p-3">Brand</th>
                        <th className="p-3">Specification</th>
                        <th className="p-3">Min Rate</th>
                        <th className="p-3">Med Rate</th>
                        <th className="p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {products.map(p => (
                        <tr key={p.id}>
                          <td className="p-3 font-semibold text-slate-800 dark:text-slate-100">{p.name}</td>
                          <td className="p-3 font-medium text-slate-600">{p.brand}</td>
                          <td className="p-3 font-mono">{p.size} {p.material && `(${p.material})`}</td>
                          <td className="p-3 text-orange-500 font-bold">₹{p.minPrice}</td>
                          <td className="p-3 text-indigo-600 font-bold">₹{p.medPrice}</td>
                          <td className="p-3 space-x-3.5">
                            <button 
                              onClick={() => setEditingProduct(p)} 
                              className="text-slate-500 hover:text-brand-orange-500"
                              title="Edit specifications"
                            >
                              <Edit3 className="w-3.5 h-3.5 inline" />
                            </button>
                            <button 
                              onClick={() => handleDeleteProduct(p.id)} 
                              className="text-slate-500 hover:text-red-600"
                              title="Delete item"
                            >
                              <Trash2 className="w-3.5 h-3.5 inline" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>
            )}

            {adminTab === 'analytics' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-3">
                    Indian Consumer & Contractor Search Statistics
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {topSearches.map((q, idx) => {
                      const maxCount = Math.max(...topSearches.map(i => i.count)) || 1;
                      const percentWidth = (q.count / maxCount) * 100;
                      return (
                        <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-150">
                          <div className="flex justify-between font-semibold text-xs text-slate-800 dark:text-slate-200 mb-1.5">
                            <span className="truncate">{q.term}</span>
                            <span className="shrink-0">{q.count} times searched</span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div 
                              className="bg-brand-orange-500 h-2 rounded-full transition-all duration-500"
                              style={{ width: `${percentWidth}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

      </section>

      {/* Catalog Search & sidebar controls list section */}
      {activeTab === 'search' && (
        <main id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Filters sidebar column */}
          <aside className="space-y-6">
            <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center justify-between border-b pb-3 mb-4">
                <h3 className="font-bold text-sm text-slate-700 dark:text-slate-200 flex items-center space-x-1.5 uppercase tracking-wider">
                  <SlidersHorizontal className="w-4 h-4 text-brand-orange-500" />
                  <span>Market Filters</span>
                </h3>
                <button 
                  onClick={() => clearAllFilters()}
                  className="text-[10px] font-bold text-brand-orange-500 hover:underline"
                >
                  Clear All
                </button>
              </div>

              {/* Special check popular items filter */}
              <div className="mb-4">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={popularOnly}
                    onChange={(e) => setPopularOnly(e.target.checked)}
                    className="rounded text-brand-orange-500 focus:ring-brand-orange-500 w-4 h-4"
                  />
                  <span className="ml-2 text-xs font-bold text-slate-700 dark:text-slate-200 uppercase flex items-center">
                    <Sparkles className="w-3.5 h-3.5 mr-1 text-yellow-500 animate-pulse" />
                    Popular Tradesman Pick
                  </span>
                </label>
              </div>

              {/* Category selector */}
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">
                    Product Category Group
                  </label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className={`w-full p-2 rounded-lg border text-xs font-semibold ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200 text-slate-800'}`}
                  >
                    <option value="">All Categories</option>
                    <option value="PTMT Fittings">PTMT Fittings</option>
                    <option value="CP Fittings">CP Fittings</option>
                    <option value="Door Fittings">Door Fittings</option>
                    <option value="Valves">Valves</option>
                    <option value="Sanitary Items">Sanitary Items</option>
                    <option value="Kitchen Fittings">Kitchen Fittings</option>
                    <option value="Plywood">Plywood Sheets</option>
                    <option value="LED Lighting">LED Lighting</option>
                    <option value="Street Lights">Street Lights</option>
                    <option value="Garden Lights">Garden Lights</option>
                    <option value="Exhaust Fans">Exhaust Fans</option>
                    <option value="Electrical Cables">Electrical Cables</option>
                    <option value="Copper Wires">Copper Wires</option>
                    <option value="Switches & Sockets">Switches & Sockets</option>
                    <option value="Electrical Protection">Electrical Protection</option>
                    <option value="Road Safety">Road Safety</option>
                  </select>
                </div>

                {/* Brand Selection list */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">
                    Listing Brand / Company
                  </label>
                  <select
                    value={selectedBrand}
                    onChange={(e) => setSelectedBrand(e.target.value)}
                    className={`w-full p-2 rounded-lg border text-xs font-semibold ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200 text-slate-800'}`}
                  >
                    <option value="">All Brands</option>
                    <option value="PRAYAG">PRAYAG</option>
                    <option value="SHAKTI">SHAKTI</option>
                    <option value="Dak Eye">Dak Eye</option>
                    <option value="JAYNAM">JAYNAM</option>
                    <option value="PRIMA">PRIMA</option>
                    <option value="Black Pearl">Black Pearl</option>
                    <option value="Crown">Crown Handles</option>
                    <option value="BVI">BVI Valves</option>
                    <option value="National Plywood">National Plywood</option>
                    <option value="Century Plywood">Century Plywood</option>
                    <option value="Polycab">Polycab</option>
                    <option value="KEI">KEI Cables</option>
                    <option value="Havells">Havells</option>
                    <option value="Philips">Philips</option>
                    <option value="Orient">Orient</option>
                    <option value="Crompton">Crompton</option>
                    <option value="Surya">Surya</option>
                    <option value="Legrand">Legrand</option>
                    <option value="BENLO">BENLO</option>
                    <option value="Finolex">Finolex</option>
                  </select>
                </div>

                {/* Sub-Filters specific to Plywood thickness */}
                {selectedCategory === 'Plywood' && (
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Plywood Thickness Spec</label>
                    <select
                      value={selectedSize}
                      onChange={(e) => setSelectedSize(e.target.value)}
                      className="w-full p-2 border rounded-lg text-xs"
                    >
                      <option value="">All Thicknesses</option>
                      <option value="12mm">12mm Standard</option>
                      <option value="18mm">18mm Waterproof</option>
                    </select>
                  </div>
                )}

                {/* Max Price quick thresholds */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Max Price Cap (₹)
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="10000"
                    step="100"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                    className="w-full accent-brand-orange-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] font-mono mt-1 font-bold">
                    <span>₹0</span>
                    <span className="text-brand-orange-500">Upto ₹{priceRange[1]}</span>
                  </div>
                </div>

              </div>
            </div>

            {/* Quick Pricing Alignment Tips Box */}
            <div className="bg-brand-blue-50 dark:bg-slate-900 shadow-sm border p-5 rounded-2xl">
              <h4 className="text-xs font-bold text-brand-blue-900 dark:text-orange-500 uppercase flex items-center mb-1.5 tracking-wider">
                <FileText className="w-4 h-4 mr-1 shrink-0" /> Spot pricing guide
              </h4>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                Wholesale listing prices represent maximum printed prices. Minimum Spot Rates represent bulk order contracting indices with standard GST inclusions.
              </p>
            </div>
          </aside>

          {/* Core Product catalog grid */}
          <section className="lg:col-span-3">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-bold text-lg font-display text-brand-blue-900 dark:text-white">
                  Active Price Listing catalog
                </h3>
                <p className="text-xs text-slate-500">Instantly comparing commercial, waterproof and heavy gauge spot rates.</p>
              </div>
              <span className="text-xs font-bold font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-1.5 px-3 rounded-lg border">
                {products.length} Products Found
              </span>
            </div>

            {/* Search items listing query result wrapper */}
            {loading ? (
              <div className="py-24 text-center">
                <RefreshCw className="w-8 h-8 text-brand-orange-500 animate-spin mx-auto mb-3" />
                <p className="text-xs font-semibold text-slate-400">Syncing live wholesale catalogs...</p>
              </div>
            ) : products.length === 0 ? (
              <div className="py-24 text-center border-2 border-dashed rounded-3xl p-6">
                <ShieldAlert className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h4 className="font-bold text-slate-800 dark:text-slate-100 text-base">No Matching Market Products Found</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Try searching with standard terms (e.g., "9W bulb" or "Plywood") or check filters to reset selected category markers.
                </p>
                <button 
                  onClick={() => clearAllFilters()}
                  className="mt-4 bg-brand-orange-500 text-white font-bold text-xs px-4 py-2 rounded-xl"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {products.map(p => {
                  const alreadyInCompare = compareList.some(item => item.id === p.id);
                  return (
                    <div 
                      key={p.id}
                      className={`rounded-2xl border overflow-hidden p-4.5 group hover:shadow-xl transition-all duration-200 flex flex-col justify-between ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}
                    >
                      <div>
                        {/* Upper image and category badges */}
                        <div className="relative aspect-video rounded-xl overflow-hidden mb-3.5 bg-slate-100 uppercase font-mono">
                          <img 
                            src={p.imageUrl} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            alt={p.name} 
                          />
                          <span className="absolute top-2 left-2 bg-brand-orange-500 text-white text-[9px] font-bold py-0.5 px-2.5 rounded-full shadow-md">
                            {p.brand}
                          </span>
                          {p.popularChoice && (
                            <span className="absolute top-2 right-2 bg-yellow-500 text-white text-[9px] font-bold py-0.5 px-2 rounded-full shadow-md animate-bounce">
                              Popular Pick
                            </span>
                          )}
                        </div>

                        {/* Category & Title */}
                        <div className="text-[10px] uppercase font-bold text-slate-400 mb-1">{p.category}</div>
                        <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100 line-clamp-2 leading-tight">
                          {p.name}
                        </h4>

                        {/* Specs size pills */}
                        <div className="flex flex-wrap gap-1.5 mt-2.5">
                          <span className="text-[10px] font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-0.5 px-2 rounded-md">
                            Size: {p.size || 'Standard'}
                          </span>
                          {p.material && (
                            <span className="text-[10px] font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-0.5 px-2 rounded-md">
                              {p.material}
                            </span>
                          )}
                          {p.watt && (
                            <span className="text-[10px] font-mono bg-orange-500/10 text-brand-orange-500 font-bold py-0.5 px-2 rounded-md">
                              ⚡ {p.watt}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Wholesaler Prices & details footer button */}
                      <div className="mt-5 border-t border-slate-100 dark:border-slate-800 pt-4.5">
                        
                        <div className="grid grid-cols-2 gap-2 mb-4">
                          <div className="bg-orange-500/5 p-2 rounded-xl border border-orange-500/10 text-center">
                            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Min Builder Rate</span>
                            <span className="text-base font-extrabold text-brand-orange-500">₹{p.minPrice}</span>
                          </div>
                          <div className="bg-indigo-500/5 p-2 rounded-xl border border-indigo-500/10 text-center">
                            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">Medium Retail Rate</span>
                            <span className="text-base font-extrabold text-brand-blue-900 dark:text-white">₹{p.medPrice}</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <button 
                            onClick={() => handleViewProduct(p)}
                            className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold py-2 px-3 rounded-xl transition-all text-center flex items-center justify-center space-x-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Details</span>
                          </button>
                          
                          <button 
                            onClick={() => toggleCompare(p)}
                            className={`p-2 rounded-xl border text-xs font-bold transition-all ${alreadyInCompare ? 'bg-indigo-500 border-indigo-500 text-white' : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200'}`}
                            title="Compare rates side-by-side"
                          >
                            <ArrowRightLeft className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </section>

        </main>
      )}

      {/* Comparisons Drawer Widget (Overlay popup at bottom when products are selected) */}
      {compareList.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-brand-blue-900 text-white shadow-2xl border-t border-white/10 p-5 rounded-t-3xl">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
              <h4 className="text-sm font-bold uppercase tracking-wide flex items-center space-x-2">
                <ArrowRightLeft className="w-4 h-4 text-brand-orange-500" />
                <span>Product Comparison Hub ({compareList.length} Selected)</span>
              </h4>
              <div className="flex items-center space-x-3">
                <button 
                  onClick={() => setCompareList([])}
                  className="text-xs font-bold text-slate-300 hover:text-white"
                >
                  Clear Comparison
                </button>
                <button 
                  onClick={() => setCompareList([])}
                  className="bg-white/10 p-1 rounded-full text-white hover:bg-white/20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {compareList.map(item => (
                <div key={item.id} className="bg-white/10 p-4.5 rounded-2xl border border-white/10 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-[10px] font-bold bg-brand-orange-500 text-white py-0.5 px-2 rounded uppercase">
                        {item.brand}
                      </span>
                      <button 
                        onClick={() => toggleCompare(item)} 
                        className="text-white/40 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <h5 className="font-bold text-xs line-clamp-1">{item.name}</h5>
                    <p className="text-[10px] text-slate-300 mt-1">Category: {item.category}</p>

                    <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
                      <div className="bg-white/5 p-1.5 rounded text-center">
                        <span className="text-[9px] block text-slate-400">Min Spot</span>
                        <span className="font-bold text-brand-orange-500">₹{item.minPrice}</span>
                      </div>
                      <div className="bg-white/5 p-1.5 rounded text-center">
                        <span className="text-[9px] block text-slate-400">Medium Spot</span>
                        <span className="font-bold text-slate-200">₹{item.medPrice}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3.5 pt-3.5 border-t border-white/10 flex justify-between items-center text-[11px] text-slate-300 font-mono">
                    <span>Spec: {item.size}</span>
                    <span>{item.material}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Detail Dialog Modal Popover */}
      {viewingDetailProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 max-w-xl w-full border border-slate-200 dark:border-slate-800 relative">
            
            <button 
              onClick={() => setViewingDetailProduct(null)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col sm:flex-row gap-6 mt-4">
              <img 
                src={viewingDetailProduct.imageUrl} 
                className="w-full sm:w-44 h-44 object-cover rounded-2xl border" 
                alt={viewingDetailProduct.name} 
              />
              
              <div className="flex-1 space-y-3">
                <span className="bg-brand-orange-500 text-white font-bold text-[9px] px-2.5 py-0.5 rounded-full uppercase">
                  {viewingDetailProduct.brand}
                </span>
                
                <h3 className="font-bold text-base text-slate-800 dark:text-slate-100 font-display">
                  {viewingDetailProduct.name}
                </h3>

                <div className="space-y-1 text-xs">
                  <p className="flex justify-between border-b pb-1">
                    <span className="text-slate-400 font-semibold">Category Group:</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{viewingDetailProduct.category}</span>
                  </p>
                  <p className="flex justify-between border-b pb-1">
                    <span className="text-slate-400 font-semibold">Size Spec:</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300">{viewingDetailProduct.size}</span>
                  </p>
                  {viewingDetailProduct.material && (
                    <p className="flex justify-between border-b pb-1">
                      <span className="text-slate-400 font-semibold">Material Grade:</span>
                      <span className="font-bold text-slate-700 dark:text-slate-300">{viewingDetailProduct.material}</span>
                    </p>
                  )}
                  {viewingDetailProduct.watt && (
                    <p className="flex justify-between border-b pb-1">
                      <span className="text-slate-400 font-semibold">Wattage Draw:</span>
                      <span className="font-bold text-brand-orange-500">{viewingDetailProduct.watt}</span>
                    </p>
                  )}
                  <p className="flex justify-between pt-1">
                    <span className="text-slate-400 font-semibold">Catalog updated:</span>
                    <span className="font-bold text-slate-500">{viewingDetailProduct.lastUpdated}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Quote Estimates & Contact WhatsApp Integrator */}
            <div className="mt-6 border-t pt-5 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Estimates spot range</span>
                  <span className="text-xl font-extrabold text-brand-blue-900 dark:text-white">
                    ₹{viewingDetailProduct.minPrice} - ₹{viewingDetailProduct.medPrice}
                  </span>
                </div>
                
                <a 
                  href={`https://api.whatsapp.com/send?phone=919876543210&text=Hello! I am seeking price availability for *${encodeURIComponent(viewingDetailProduct.brand)} ${encodeURIComponent(viewingDetailProduct.name)}* with Min Builder Rate: ₹${viewingDetailProduct.minPrice} and Medium Retail Price: ₹${viewingDetailProduct.medPrice}. Please confirm.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#25D366] text-white hover:bg-[#128C7E] px-4 py-2.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition-all shadow-md"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>WhatsApp Inquiry</span>
                </a>
              </div>

              <div className="text-[10px] text-slate-400 leading-relaxed">
                <span>Reference Attachment: <strong>{viewingDetailProduct.sourcePdf || 'Local Database Index'}</strong>. Prices align with standard medium/budget Indian tradesman levels.</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Footer Branding Area */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 py-8 bg-slate-50 dark:bg-slate-900/60 transition-all text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-xs text-slate-400 space-y-2">
          <p className="font-semibold text-slate-500 dark:text-slate-300">
            Price Finder Indian Trades Database Division | gulubasini18@gmail.com
          </p>
          <p className="max-w-xl mx-auto leading-relaxed text-[11px]">
            We aggregate minimum contractor spot rates and medium retailer averages. Ideal for shopkeepers, plumbers, electricians, and constructors. Fully searchable and synchronized offline.
          </p>
          <p className="text-[10px] text-slate-500 pt-3">
            Disclaimer: Prices listed are index averages. Standard state taxation, GST clearances, and transport freights apply extra.
          </p>
        </div>
      </footer>

    </div>
  );
}

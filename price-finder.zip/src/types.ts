export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string; // e.g. "PTMT Fittings", "CP Fittings", "Door Fittings", "Valves", "Sanitary Items", "Kitchen Fittings", "Plywood", "LED Lighting", "Street Lights", "Garden Lights", "Exhaust Fans", "Electrical Cables", "Copper Wires", "Switches & Sockets", "Electrical Protection"
  subcategory: string;
  size: string; // e.g. "15mm", "18mm", "9W", "3.5 Core 35 sq mm", etc.
  material?: string; // e.g. "PTMT", "Brass (CP)", "Aluminium", "Cast Iron", "PVC", "XLPE", "Waterproof Plywood", etc.
  minPrice: number;
  medPrice: number;
  imageUrl?: string;
  lastUpdated: string;
  sourcePdf?: string;
  
  // Electrical special fields
  watt?: string; // e.g. "9W", "50W"
  voltage?: string; // e.g. "230V", "1100V"
  coreType?: string; // e.g. "Single Core", "2 Core", "3 Core", "3.5 Core", "4 Core"
  wireGauge?: string; // e.g. "1.5 sq mm", "14 SWG"
  ipRating?: string; // e.g. "IP65", "IP66"
  motorType?: string; // e.g. "Copper Motor", "Aluminum Motor"
  energyEfficiency?: string; // e.g. "5 Star", "3 Star"
  indoorOutdoor?: 'Indoor' | 'Outdoor' | 'Both';
  popularChoice?: boolean;
}

export interface CableCalculationInput {
  loadType: 'KW' | 'HP' | 'Amps';
  loadValue: number;
  voltage: 'Single Phase (230V)' | 'Three Phase (415V)';
  cableLength: number; // in meters
  installationType: 'Direct in Ground' | 'In Duct' | 'In Air';
  conductorType: 'Aluminium' | 'Copper';
  cableType: 'XLPE Armoured' | 'PVC Flexible';
}

export interface CableCalculationResult {
  recommendedSize: string;
  ampacity: number;
  voltageDrop: number;
  voltageDropPercent: number;
  voltageDropLimitExceeded: boolean;
  minPricePerMeter: number;
  medPricePerMeter: number;
  brandName: string;
}

export interface PDFUploadHistory {
  id: string;
  fileName: string;
  brand: string;
  category: string;
  uploadDate: string;
  extractedCount: number;
  version: string;
  status: 'Completed' | 'Processing' | 'Failed';
}

export interface SearchTermAnalytics {
  term: string;
  count: number;
  timestamp: string;
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  timestamp: string;
}

export interface RecentlyViewedItem {
  productId: string;
  viewedAt: string;
}
